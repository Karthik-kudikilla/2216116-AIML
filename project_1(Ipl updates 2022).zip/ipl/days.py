import d
def days(day):
    print('######################')
    if(day==1):
        a=day
        print('DAY-',day)
        l=['CSK','KKR']
        print('The match is between:')
        print(l[0],'VS',l[1])
        print('The match won by kkr by 8 wickets')
        p=int(input('Do u want information about the players'))
        if(p==1):
            print(d.team(a))
    if(day==2):
        a = day
        print('DAY-', day)
        l = ['MI', 'DC']
        print('The match is between:')
        print(l[0], 'VS', l[1])
        print('The match won by DC by 4 wickets')
        p = int(input('Do u want information about the players'))
        if (p == 1):
            print(d.team(a))
    if (day == 3):
        a = day
        print('DAY-', day)
        l = ['RCB', 'PBKS']
        print('The match is between:')
        print(l[0], 'VS', l[1])
        print('PBKS won by 5 wickets')
        p = int(input('Do u want information about the players'))
        if (p == 1):
            print(d.team(a))
    if (day == 4):
        a = day
        print('DAY-', day)
        l = ['LSG', 'GT']
        print('The match is between:')
        print(l[0], 'VS', l[1])
        print('GT won by 5 wickets')
        p = int(input('Do u want information about the players'))
        if (p == 1):
            print(d.team(a))
    if (day == 5):
        a = day
        print('DAY-', day)
        l = ['RR', 'SRH']
        print('The match is between:')
        print(l[0], 'VS', l[1])
        print('The match won by RR by 61 runs')
        p = int(input('Do u want information about the players'))
        if (p == 1):
            print(d.team(a))
    if (day == 6):
        a = day
        print('DAY-', day)
        l = ['RCB', 'KKR']
        print('The match is between:')
        print(l[0], 'VS', l[1])
        print('RCB won by 3 wickets')
        p = int(input('Do u want information about the players'))
        if (p == 1):
            print(d.team(a))
    if (day == 7):
        a = day
        print('DAY-', day)
        l = ['CSK', 'LSG']
        print('The match is between:')
        print(l[0], 'VS', l[1])
        print('LSG won by 6 wickets')
        p = int(input('Do u want information about the players'))
        if (p == 1):
            print(d.team(a))
    if (day == 8):
        a = day
        print('DAY-', day)
        l = ['PBKS', 'KKR']
        print('The match is between:')
        print(l[0], 'VS', l[1])
        print('KKR won by 6 wickets')
        p = int(input('Do u want information about the players'))
        if (p == 1):
            print(d.team(a))
    if (day == 9):
        a = day
        print('DAY-', day)
        l = ['RR', 'MI']
        print('The match is between:')
        print(l[0], 'VS', l[1])
        print('RR won by 23 runs')
        p = int(input('Do u want information about the players'))
        if (p == 1):
            print(d.team(a))
    if (day == 10):
        a = day
        print('DAY-', day)
        l = ['GT', 'DC']
        print('The match is between:')
        print(l[0], 'VS', l[1])
        print('GT won by 14 runs')
        p = int(input('Do u want information about the players'))
        if (p == 1):
            print(d.team(a))
    print("###################")






