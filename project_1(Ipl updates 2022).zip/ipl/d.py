def team(a):
    if a==1:
        print('-----------CSK-(135/5(20))------------')
        dic={'MS Dhoni':'50*(30)','Robin':'28(21)','Ravindra jadeja':'26(28)','Umesh yadav':'2/20(4)','Varun':'1/23(4)'}
        for key,values in dic.items():
            print(key,':',values)
        print('----------KKR-(133/4(18.3)------------')
        dic = {'Ajinkya Rahane': '44*(34)', 'Sam Billings': '25(21)', 'Nitish rana': '21(17)', 'Dwayne Bravo': '3/20(4)',
               'Mitchel santher': '1/23(4)'}
        for key, values in dic.items():
            print(key, ':', values)
    elif a==2:
        print('-----------MI-(177/5(20))------------')
        dic = {'Ishan kishan': '81*(30)', 'Rohit sharma': '41(32)', 'Tilak varma': '22(15)', 'Kuldeep yadav': '3/18(4)',
               'Khaleel ahmed': '2/27(4)'}
        for key, values in dic.items():
            print(key, ':', values)
        print('----------DC-(179/6(18.2)------------')
        dic = {'Lalit yadav': '48*(38)', 'Axar patel': '38*(21)', 'Pritvi shaw': '38(24)',
               'Basil Thampi': '3/20(4)',
               'Murugan Ashwin': '2/14(4)'}
        for key, values in dic.items():
            print(key, ':', values)
    elif a == 3:
        print('------------lsg.158/6(20)---------')
        dic = {'deepak hooda': '55(41)', 'ayush badoni': '54(41)', 'krunal panday': '21*(31)', 'mohammed': '3/25(4)',
               'varun aron': '2/45(4)', 'rashid khan': '1/27(4)'}
        for key, values in dic.items():
            print(key, ':', values)
        print('----------titans.161/5(19.4)---------')
        dic = {'rahul tewatia': '40*(24)', 'hardik panday': '33(28)', 'david miler': '30(21)', 'chameera': '2/22(3)',
               'krunal': '1/17(4)', 'deepak hooda': '1/31(3)'}
        for key, values in dic.items():
            print(key, ':', values)
    elif a==4:
        if a == 4:
            print('----------royal.210/6(20)---------')
            dic = {'sanju': '55*(27)', 'devdutt pandikkal': '41(29)', 'jos buttler': '35(28)',
                   'umaran malik': '2/39(4)',
                   't.natarajan': '2/43(4)', 'bhanvneshear kumar': '1/29(4)'}
            for key, values in dic.items():
                print(key, ':', values)
            print('----------sunrisers.149/7(20)---------')
            dic = {'aidan markram': '57*(41)', 'washington sundar': '40(14)', 'romario': '24(18)',
                   'yuzvendra chahal': '3/22(4)',
                   'prasidh': '2/16(4)', 'trent boult': '2/23(4)'}
            for key, values in dic.items():
                print(key, ':', values)
    elif a==5:

                print('-----------RR - (210 / 6(20)) - ---------')
                dic = {'Sanju Samson': '55(27)', 'Padikkalo': '41(29)', 'Jos Butler': '35(28)',
                       'Umran Malik': '2/39(4)', 'Bhuvaneshvar Kumar': '1/29(4)'}
                for key, values in dic.items():
                    print(key, ':', values)

                print('---------SRH - (149 / 7(20)) - ----------')
                dic = {'Aiden Markram': '57(41)', 'Romario Shepherd': '24(18)', 'Washington Sundar': '40(14)',
                       'Yuzvender Chahal': '3/22(4)', 'Trent Boult': '2/23(4)'}
                for key, values in dic.items():
                    print(key, ':', values)
    elif a == 6:
            print('----------KKR-128(18.5)----------')
            dic = {'andre russell': '25(18)', 'umesh yadav': '18(12)', 'sam billings': '14(15)',
                   'wanindu hasaranga': '4/20(4)', 'akash deep': '3/45(3.5)', 'harshal patel': '2/11(4)'}
            for key, values in dic.items():
                print(key, ':', values)
            print('----------RCB-132/7(19.2)--------')
            dic = {'sherfane rutherford': '28(40)', 'shahbaz ahmed': '27(20)', 'david willey': '18(28)',
                   'tim southee': '3/20(4)', 'umesh yadav': '2/16(4)', 'sunil narine': '1/12(4)'}
            for key, values in dic.items():
                print(key, ':', values)
    elif a == 7:
            print('----------CSK-210/7(20)----------')
            dic = {'Robin Uthappa': '50(27)', 'shivam dube': '49(30)', 'moeen ali': '35(22)', 'ravi bishnoi': '2/24(4)',
                   'anvesh khan': '2/38(4)', 'andrew tye': '2/40(4)'}
            for key, values in dic.items():
                print(key, ':', values)
            print('----------LSG-211/4(19.3)--------')
            dic = {'quinton de kock': '61(45)', 'evin lewis': '55*(23)', 'kl rahul': '40(26)',
                   'dwaine pretorius': '2/31(4)', 'dwayne bravo': '1/35(4)', 'tushar': '1/40(4)'}
            for key, values in dic.items():
                print(key, ':', values)
    elif a == 8:
            print('----------PBKS-137(18.2)----------')
            dic = {'Bhanuka rajapaksa': '31(9)', 'kagiso rabada': '25(16)', 'liam livingstone': '19(16)',
                   'umesh yadav': '4/23(4)', 'tim southee': '2/36(4)', 'andre russell': '1/0(0.2)'}
            for key, values in dic.items():
                print(key, ':', values)
            print('----------KKR-141/4(14.3)--------')
            dic = {'andre russell': '70*(31)', 'shreyas iyer': '26(15)', 'sam billings': '24*(23)',
                   'rahul chahar': '2/13(4)', 'kagiso rabada': '1/23(3)', 'odean smith': '1/39(2)'}
            for key, values in dic.items():
                print(key, ':', values)
    elif a == 9:
            print('----------RR-193/8(20)----------')
            dic = {'jos buttler': '100(68)', 'shimron hetmyer': '35(14)', 'sanju samson': '30(21)',
                   'jasprit bumrah': '3/17(4)', 'tymal mills': '3/35(4)', 'kieron pollard': '1/46(4)'}
            for key, values in dic.items():
                print(key, ':', values)
            print('----------MI-170/8(20)  --------')
            dic = {'tilak varma': '61(33)', 'ishan kishan': '54(43)', 'kieron pollard': '22(24)',
                   'yuzvendra chahal': '2/26(4)', 'navdeep saini': '2/36(3)', 'trent boult': '1/29(4)'}
            for key, values in dic.items():
                print(key, ':', values)
    elif a == 10:
        print('-------------GT-(171/6(20))-------------')
        dic = {'shubman gill': '84*(46)', 'mustafizur rahman': '3 / 21(4)','hardik pandya':'31 * (27)','khaleel ahmed':'2 / 23 * (4)','david miller':'20 * (15)'}
        for key, values in dic.items():
            print(key, ':', values)
        print('-----------------DC-157/9*(20---------------')
        dic = {'rishabh pant': '43*(29)', 'lockie ferguson': '4/28*(4)', 'lalit yadav': '25*(22)',
               'mohammed shami': '2/30*(4)', 'rovaman powell': '20*(12)'}
        for key, values in dic.items():
            print(key, ':', values)

