def team_players(team_name):
    li = ['player_name      Role       Strike_rate/Economy']
    if team_name=='mi'or team_name=='MI':
        di={'Rohith Sharma':['Batter','190'],
            'Ishan Kishan':['Batter','160'],
            'SuryaKumar yadav':['Batter','180'],
            'Tilak Varma': ['Batter', '170'],
            'Kieran Polard': ['All Rounder','180/9.8'],
            'Jasprit Bumrah': ['Bowler', '6.5'],
            'Jofra Archer': ['Bowler', '7.2'],
            'Sams': ['Bowler', '8.2'],
            'Mayank': ['Bowler', '6.8'],
            'Tim David': ['batter', '390'],
            'Tymal Mills': ['Bowler', '9.8']
            }
        print(li)
        for key, value in di.items():
            print(key, ' : ', value)
        return "Here they are"

    elif team_name=='csk'or team_name=='CSK':
        di={'Rururaj Gaikward':['Batter','190'],
            'MS Dhoni':['Batter','160'],
            'Moen Ali':['Batter','180'],
            'Ravindra Jadeja': ['All Rounder','180/10.0'],
            'Deepak Chahar': ['Bowler', '6.5'],
            }
        print(li)
        for key, value in di.items():
            print(key, ' : ', value)
        return "Here they are"

    elif team_name=='rcb'or team_name=='RCB':
        di={'Virat Kohli':['Batter','190'],
            'Anuj Rawath':['Batter','160'],
            'Rajat Patidhar':['Batter','180'],
            'MAxwell': ['All Rounder','180/10.0'],
            'Harshal Patel': ['Bowler', '6.5'],
            }
        print(li)
        for key, value in di.items():
            print(key, ' : ', value)
        return "Here they are"

    elif team_name=='pbks'or team_name=='PBKS':
        di={'Shikhar Dhawan':['Batter','190'],
            'Liam Livingstone':['Batter','250'],
            'Mayank Agarwal':['Batter','180'],
            'Sharukh Khan': ['All Rounder','180/10.0'],
            'Rabada': ['Bowler', '6.5'],
            }
        print(li)
        for key, value in di.items():
            print(key, ' : ', value)
        return "Here they are"

    elif team_name=='rr'or team_name=='RR':
            di = {'sanju': ['wicket-kepper', '100'],
                  'jos buttler': ['wicket-kepper', '160'],
                  'bastsman': ['batsman', '199'],
                  'jos buttle': ['wicket-kepper', '157'],
                  'ternt boult': ['bowler', '12.2'],
                  'daryl mitchell': ['all-rounder', '130/12.1']
                  }
            print(li)
            for key, value in di.items():
                print(key, ' : ', value)
            return "Here they are"

    elif team_name == 'srh' or team_name=='SRH':
        di = {'nicholas': ['wicket-kepper', '130'],
              'glenn philips': ['wicket-kepper', '100'],
              'aiden markar': ['batsman', '124'],
              'vishnu vinod': ['wicket-kepper', '120'],
              'sushant mishra': ['bowler', '9.7'],
              'daryl mitchell': ['all-rounder', '125/11.0']
              }
        print(li)
        for key, value in di.items():
            print(key, ' : ', value)
        return "Here they are"

    elif team_name == 'kkr' or team_name=='KKR':
        di = {'sam': ['wicket-kepper', '190'],
              'shedonjackson': ['wicket-kepper', '160'],
              'sheryas layer': ['batsman', '122'],
              'Rinku ': ['wicket-kepper', '167'],
              'umesh yadav': ['bowler', '5.5'],
              'sunil narine': ['all-rounder', '110/6.8']
              }
        print(li)
        for key, value in di.items():
            print(key, ' : ', value)
        return "Here they are"

    elif team_name == 'GT' or team_name=='gt':
        di = {'Wriddhiman Saha': ['Batter', '130'],
              'Shubman Gill': ['Batter', '150'],
              'Hardik Pandya': ['All Rounder', '200/9.8'],
              'Sai Sudharsan': ['Batter', '113'],
              'David Miller': ['Batter', '152'],
              'Rahul Tewatia': ['Batter', '120'],
              'Rashid Khan': ['Batter', '130'],
              'Pradeep Sangwan': ['Batter', '110'],
              'Alzarri Joseph': ['Bowler', '6.8']
              }
        print(li)
        for key, value in di.items():
            print(key, ' : ', value)
        return "Here they are"

    elif team_name == 'LSG' or team_name=='lsg':
        di = {'KL Rahul': ['Batsman', '130'],
              'Marcus Stoinis': ['	All-Rounder', '150'],
              'Ravi Bishnoi': ['	Bowler', '4.5'],
              'Manish Pandey': ['Batter', '113'],
              'Jason Holder': ['All-Rounder', '152'],
              }
        print(li)
        for key, value in di.items():
            print(key, ' : ', value)
        return "Here they are"


    elif team_name == 'dc' or team_name=='DC':
        di = {'Prithvi Shaw': ['Batter', '190'],
              'Rishabh Pant': ['Batter', '140'],
              'Axar Patel': ['All Rounder', '200/9.8'],
              'Bharath KS': ['Batter', '130'],
              'David Warner': ['Batter', '110'],
              'Shardhul Thakur': ['Bowler', '6.8']
              }
        print(li)
        for key, value in di.items():
            print(key, ' : ', value)
        return "Here they are"

