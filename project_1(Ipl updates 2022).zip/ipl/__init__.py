print('WELCOME TO THE IPL 2022')
print('1.The info about the Players ')
print('2.Day wise matches')
c=int(input('Choose the options'))
if c==1:
    team_name=input('Enter the team name')
    import players as p
    p.team_players(team_name)
if c==2:
    day=int(input('Enter the day'))
    import days as d
    d.days(day)
